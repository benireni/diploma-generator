#pragma once

#include "./audioSines.h"

// Extracts audio sines from .wav given file
AudioSines *extractAudioDataFromFile(char *wavFilename);
