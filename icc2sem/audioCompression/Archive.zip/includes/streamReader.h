#pragma once

#define INITIAL_SIZE 8

#define STR_MAX_LENGTH 100

typedef enum{false, true} bool;

// Reads next line from
char *readLine(FILE *stream);
