class Polygon:
    def __init__(self, color: str, isFilled: bool) -> None:
        self.color: str = color
        self.isFilled: bool = isFilled