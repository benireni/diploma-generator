class Card():
    def __init__(self, suit, value) -> None:
        self.suit = suit
        self.value = value